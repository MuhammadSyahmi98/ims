
<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="stylesheets/style.css">
  
</head>
<body>
<?php include_once('layouts/header.php'); ?>
<?php include_once('layouts/menu.php'); ?>

<div class="body1">
	<div class="welcome">
		<h3>WELCOME!</h3>
	</div>
	<div class="welcome1">
		<div>Just browes around and find out<br> what page you can access</div>
	</div>
</div>

</body>
</html>

