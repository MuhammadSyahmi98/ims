<?php
	
	// Create connection
	$conn =mysqli_connect("localhost","muhammad_user1","H89EPXkT^^m4","muhammad_db");

	// Check connection
	if (mysqli_connect_errno())
  {
    echo  'Error';

  }
?>
