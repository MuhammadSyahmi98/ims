How to run the Inventory Management System
1. Paste folder workshop1 to inside root directory(for xampp/htdocs).
2. Open PHPMyAdmin
3. Create a database with name db
4. import db.sql file or copy the scripts and paste at sql statment
5. Run the script http://localhost/workshop1 (frontend)

Admin
Username:admin
Password:admin

Special
Username: special
Password: special

staff/user
Username: user
Password: user


Name: Muhammad Syahmi Bin Abdul Jalil
No. Matric: B031810288
Email: B031810288@student.utem.edu.my