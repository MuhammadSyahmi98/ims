    

<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
  <link rel="stylesheet" type="text/css" href="stylesheets/style.css">
  
</head>
<body>
<?php include_once('layouts/header.php'); ?>
<?php include_once('layouts/menu.php'); ?>

 <div class="col-md-12">
    <div class="panel">
      <div class="jumbotron text-center">
         <h1>Welcome!</h1>
         <p>Just browes around and find out what page you can access.</p>
      </div>
    </div>
 </div>
</div>



</body>
</html>


